const apiKey = '0f27f491c7484afa9563ca935d2489f8'; // مفتاح API للأخبار
const apiUrl = `https://newsapi.org/v2/top-headlines?country=us&apiKey=${apiKey}`;

function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.classList.add('hidden');
    });
    document.getElementById(sectionId).classList.remove('hidden');
}

function download() {
    const url = document.getElementById('url-input').value;
    // هنا يمكنك إضافة الكود اللازم لتنزيل المحتوى من الرابط
    alert(`Download initiated for: ${url}`);
}

async function fetchNews() {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        displayNews(data.articles);
    } catch (error) {
        console.error('Error fetching news:', error);
    }
}

function displayNews(articles) {
    const container = document.getElementById('news-container');
    container.innerHTML = '';

    articles.forEach(article => {
        const newsItem = document.createElement('div');
        newsItem.classList.add('news-item');

        newsItem.innerHTML = `
            <img src="${article.urlToImage || 'https://via.placeholder.com/600x400'}" alt="News Image">
            <h2><a href="${article.url}" target="_blank">${article.title}</a></h2>
            <p>${article.description || 'No description available'}</p>
        `;

        container.appendChild(newsItem);
    });
}

// Fetch news when the page loads
window.onload = function() {
    fetchNews();
    showSection('downloader');
};